import json 
import boto3
import time 
from kafka import KafkaConsumer
print("[OK] Kafka Consumer Connected")

s3 = boto3.client(
    "s3",
    aws_access_key_id="AKIAQ2T77SDUILNA3MAK",
    aws_secret_access_key="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",
    region_name = 'us-east-1'
)

bucket_name = 'stock-etl-project-kafka-data'

try:
    s3.head_bucket(Bucket=bucket_name)
    print(f"Bucket {bucket_name} is exist and acessible.")
except Exception as e:
    print("[Not OK] Bucket not found or access denied:", e)
    exit()

## Kafka Consumer >> 
consumer = KafkaConsumer(
    'stock_data',   # ✅ EXACT match
    bootstrap_servers=["localhost:29092"],
    auto_offset_reset='earliest',
    enable_auto_commit=True,
    group_id="bronze-consumer1",
    value_deserializer=lambda v: json.loads(v.decode("utf-8")))

print("[OK] Consumer streaming and saving to AWS Bucket...")

for message in consumer:
    record = message.value
    symbol=record.get('symbol','unknown')
    ts=record.get('fetched_at',int(time.time()))
    key=f"{symbol}/{ts}.json"

    s3.put_object(
        Bucket = bucket_name,
        Key = key,
        Body = json.dumps(record),
        ContentType="application/json")
    
    print(f"[OK] Saved record for {symbol} = s3://{bucket_name}/{key}")


