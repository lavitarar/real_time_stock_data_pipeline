import time
import json
import requests
from kafka import KafkaProducer

# CONFIG >>>>>>>>
API_KEY = "d7aitg9r01qmvlmg4uf0d7aitg9r01qmvlmg4ufg"
BASE_URL = "https://finnhub.io/api/v1/quote"
SYMBOLS = ["AAPL", "MSFT", "TSLA", "GOOGL", "AMZN"]

KAFKA_TOPIC = "stock_data"

# KAFKA PRODUCER >>>>>
producer = KafkaProducer(
    bootstrap_servers="localhost:29092",
    api_version = (0,10,1),
    value_serializer=lambda v: json.dumps(v).encode("utf-8"))
print("[OK] Kafka Producer Connected")

#Retrieve Data >>>

def fetch_quote(symbol):
    url=f"{BASE_URL}?symbol={symbol}&token={API_KEY}"
    try:
        response=requests.get(url=url)
        response.raise_for_status()
        data=response.json()
        data['symbol']=symbol
        data["fetched_at"] = int (time.time())
        return data
    except Exception as e:
        print(f'Error Fetching >> {symbol} : {e}')
        return None

#Looping and Pushing to Stream >>>
 
while True:
    for symbol in SYMBOLS:
        quote = fetch_quote(symbol)
        if quote:
            print(f'Producing: {quote}')
            producer.send('stock_data', value=quote)

    producer.flush()   
    time.sleep(6)






